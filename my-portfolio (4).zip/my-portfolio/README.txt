HAMNA AKRAM PORTFOLIO WEBSITE

Open index.html in any browser to view it. No install needed.

FILES
  index.html   page structure. Change your name, email, about text and skills here.
  content.js   YOUR SECTIONS AND PROJECTS. This is the main file to edit.
  style.css    colours, fonts and layout.
  script.js    the page logic (usually no need to touch).
  media/       your videos and images.

PUT IT ONLINE (keeps everything working)
  Netlify Drop (app.netlify.com/drop): drag this whole folder onto the page. You get a link.
  Or GitHub Pages / Cloudflare Pages.
  You can then link to that address from Google Sites using a button or link.

GOOGLE SITES NOTE
  Google Sites only embeds a single block of code in a frame and blocks local files,
  so videos in the media folder will not load there. Host the folder as above instead.
