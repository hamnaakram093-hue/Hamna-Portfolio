

const $=s=>document.querySelector(s),grid=$("#grid"),dlg=$("#dlg"),dbox=$("#dbox");
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const isFile=u=>/\.(mp4|webm|ogg)(\?.*)?$/i.test(u)||u.startsWith("data:video");
const draw={
 gear:'<circle cx="160" cy="100" r="46"/><circle cx="160" cy="100" r="16"/><path d="M160 46v-14M160 168v-14M106 100H92M228 100h-14M122 62l-10-10M208 148l-10-10M198 62l10-10M112 148l10-10"/><circle cx="160" cy="100" r="60" stroke-dasharray="6 4"/>',
 bracket:'<path d="M80 150V60h50v50h110v40z"/><circle cx="105" cy="85" r="10"/><circle cx="215" cy="130" r="8"/><path d="M60 170h200M60 164v12M260 164v12" stroke-dasharray="none"/>',
 plate:'<rect x="70" y="50" width="180" height="100" rx="12"/><circle cx="100" cy="80" r="9"/><circle cx="220" cy="80" r="9"/><circle cx="100" cy="120" r="9"/><circle cx="220" cy="120" r="9"/><path d="M130 100h60M160 70v60" stroke-dasharray="6 4"/>'
};
const thumb=p=>p.image?`<img src="${esc(p.image)}" alt="${esc(p.title)}" loading="lazy">`:
 `<svg viewBox="0 0 320 200" fill="none" stroke="var(--ink)" stroke-width="2" role="img" aria-label="Drawing placeholder for ${esc(p.title)}">${draw[p.shape]||draw.plate}</svg>`;

function render(list,grid){
  grid.innerHTML=list.length?"":'<p class="empty">Coming soon.</p>';
  list.forEach(p=>{
    const b=document.createElement("button");b.className="card";
    b.innerHTML=`<div class="thumb">${thumb(p)}${p.video?'<span class="badge">Video</span>':""}</div><div class="info"><h3>${esc(p.title)}</h3><p>${esc(p.desc)}</p><div class="tags">${p.tags.map(t=>`<span>${esc(t)}</span>`).join("")}</div></div>`;
    b.onclick=()=>open(p);grid.appendChild(b);
  });
}
function open(p){
  const G=p.gallery&&p.gallery.length?p.gallery:null,big=(u,a)=>`<img src="${esc(u)}" alt="${esc(a)}">`;
  let m;
  if(p.video&&isFile(p.video))m=`<video controls preload="metadata" ${p.image?`poster="${esc(p.image)}"`:""} src="${esc(p.video)}"></video>`;
  else if(p.image)m=big(p.image,p.title);
  else m=`<div>Pictures and video for this project coming soon.</div>`;
  const links=(p.links||[]).map(([l,u])=>`<a class="btn" href="${esc(u)}" target="_blank" rel="noopener">${esc(l)}</a>`).join(" ");
  const gal=G?`<div class="gal">${G.map(([u,c],i)=>`<button type="button" data-i="${i}"><img src="${esc(u)}" alt="${esc(c)}" loading="lazy"><span>${esc(c)}</span></button>`).join("")}</div>`:"";
  dbox.innerHTML=`<div class="media">${m}</div>${gal}<div class="dbody"><div><h3>${esc(p.title)}</h3><p>${esc(p.long)}</p><div class="tags">${p.tags.map(t=>`<span>${esc(t)}</span>`).join("")}</div>${links?`<p class="lk">${links}</p>`:""}</div><dl>${Object.entries(p.specs).map(([k,v])=>`<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join("")}<dt>Year</dt><dd>${p.year}</dd></dl></div>`;
  dbox.querySelectorAll(".gal button").forEach(b=>b.onclick=()=>{const[u,c]=G[+b.dataset.i];dbox.querySelector(".media").innerHTML=big(u,c)});
  dlg.showModal();
}
$("#x").onclick=()=>{dlg.close();dbox.innerHTML=""};
dlg.addEventListener("click",e=>{if(e.target===dlg){dlg.close();dbox.innerHTML=""}});
dlg.addEventListener("close",()=>{dbox.innerHTML=""});
$("#groups").innerHTML=GROUPS.map(g=>`<section id="${g.id}"><h2 class="big">${g.title}</h2><p class="intro">${g.intro}</p>${g.subs.map(([k,t,n])=>`<div class="sub" id="${k}"><h3>${t}</h3>${n?`<p class="note">${n}</p>`:""}<div class="grid" data-cat="${k}"></div></div>`).join("")}</section>`).join("");
document.querySelectorAll("[data-cat]").forEach(el=>render(PROJECTS.filter(p=>p.cat===el.dataset.cat),el));
$("#jump").innerHTML=GROUPS.map(g=>`<div class="jg"><a class="jmain" href="#${g.id}">${g.title}</a><div class="jsubs">${g.subs.map(([k,t])=>`<a href="#${k}">${t}</a>`).join("")}</div></div>`).join("");

/* wireframe spur gear */
(function(){
  const cv=$("#cv"),c=cv.getContext("2d"),T=14,R1=1,R2=1.28,H=.45;
  const prof=[];for(let i=0;i<T;i++){const a=i/T*Math.PI*2,w=Math.PI*2/T;
    [[0,R1],[.2,R2],[.5,R2],[.7,R1]].forEach(([o,r])=>prof.push([Math.cos(a+o*w)*r,Math.sin(a+o*w)*r]))}
  const hole=[];for(let i=0;i<24;i++){const a=i/24*Math.PI*2;hole.push([Math.cos(a)*.35,Math.sin(a)*.35])}
  let ry=0.6,rx=-.9,drag=false,lx=0,ly=0;
  function size(){const d=devicePixelRatio||1,r=cv.getBoundingClientRect();cv.width=r.width*d;cv.height=r.height*d;c.setTransform(d,0,0,d,0,0)}
  function proj(x,y,z,w,h){
    let X=x*Math.cos(ry)+y*Math.sin(ry),Y=-x*Math.sin(ry)+y*Math.cos(ry),Z=z;
    const Y2=Y*Math.cos(rx)-Z*Math.sin(rx),Z2=Y*Math.sin(rx)+Z*Math.cos(rx),s=Math.min(w,h)*.3,f=1/(1-Z2*.12);
    return[w/2+X*s*f,h/2+Y2*s*f]}
  function loop(){
    const r=cv.getBoundingClientRect(),w=r.width,h=r.height,cs=getComputedStyle(document.documentElement);
    c.clearRect(0,0,w,h);if(!drag)ry+=.006;
    const ring=(pts,z,col,lw)=>{c.beginPath();pts.forEach(([x,y],i)=>{const[a,b]=proj(x,y,z,w,h);i?c.lineTo(a,b):c.moveTo(a,b)});c.closePath();c.strokeStyle=col;c.lineWidth=lw;c.stroke()};
    const ink=cs.getPropertyValue("--ink").trim(),acc=cs.getPropertyValue("--accent").trim();
    c.globalAlpha=.4;prof.forEach((p,i)=>{if(i%2===0){c.beginPath();let a=proj(p[0],p[1],-H,w,h),b=proj(p[0],p[1],H,w,h);c.moveTo(...a);c.lineTo(...b);c.strokeStyle=ink;c.lineWidth=1;c.stroke()}});c.globalAlpha=1;
    ring(prof,-H,ink,1.6);ring(prof,H,ink,1.6);ring(hole,-H,acc,1.6);ring(hole,H,acc,1.6);
    hole.forEach((p,i)=>{if(i%4===0){c.beginPath();c.moveTo(...proj(p[0],p[1],-H,w,h));c.lineTo(...proj(p[0],p[1],H,w,h));c.strokeStyle=acc;c.lineWidth=1;c.stroke()}});
    requestAnimationFrame(loop)}
  cv.addEventListener("pointerdown",e=>{drag=true;lx=e.clientX;ly=e.clientY;cv.setPointerCapture(e.pointerId)});
  cv.addEventListener("pointermove",e=>{if(drag){ry+=(e.clientX-lx)*.01;rx=Math.max(-1.5,Math.min(-.2,rx+(e.clientY-ly)*.01));lx=e.clientX;ly=e.clientY}});
  cv.addEventListener("pointerup",()=>drag=false);
  addEventListener("resize",size);size();
  if(matchMedia("(prefers-reduced-motion:reduce)").matches){ry=.6;const l=loop;requestAnimationFrame(()=>{drag=true;l();});}else loop();
})();
